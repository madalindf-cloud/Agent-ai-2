package ro.x67.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class Elem(val id: Int, val rect: Rect, val label: String, val kind: String)

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        val log = StringBuffer()
        fun addLog(s: String) {
            log.append(s).append('\n')
            if (log.length > 6000) log.delete(0, log.length - 6000)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    @Volatile var running = false
    @Volatile var stopRequested = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- floating button ----------
    private fun showBubble() {
        val tv = TextView(this)
        tv.text = "AI"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.gravity = Gravity.CENTER
        tv.setTypeface(null, Typeface.BOLD)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xCC1565C0.toInt())
        tv.background = bg
        val size = (52 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 400
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleClick()
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun onBubbleClick() {
        if (running) {
            stopRequested = true
            addLog("Oprit de utilizator")
        } else {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
    }

    private fun updateBubble() {
        main.post {
            bubble?.text = if (running) "STOP" else "AI"
            (bubble?.background as? GradientDrawable)?.setColor(
                if (running) 0xCCD32F2F.toInt() else 0xCC1565C0.toInt()
            )
        }
    }

    fun say(msg: String) {
        addLog(msg)
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    fun startTask(task: String) {
        if (running) return
        running = true
        stopRequested = false
        updateBubble()
        addLog("▶ $task")
        Thread {
            try {
                Agent(this).execute(task)
            } catch (e: Exception) {
                say("Eroare: ${e.message}")
            } finally {
                running = false
                updateBubble()
            }
        }.start()
    }

    // ---------- phone control primitives (call from background thread) ----------
    fun screenshot(): Bitmap? {
        repeat(3) {
            var bmp: Bitmap? = null
            val latch = CountDownLatch(1)
            takeScreenshot(
                Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = r.hardwareBuffer
                            bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                        } catch (e: Exception) {
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        latch.countDown()
                    }
                }
            )
            latch.await(5, TimeUnit.SECONDS)
            val got = bmp
            if (got != null) return got
            Thread.sleep(1300)
        }
        return null
    }

    private fun gesture(path: Path, duration: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        val started = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!started) return false
        latch.await(5, TimeUnit.SECONDS)
        return ok
    }

    fun tap(x: Float, y: Float, duration: Long): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return gesture(p, duration)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        return gesture(p, duration)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val f = findEditable(c)
            if (f != null) return f
        }
        return null
    }

    fun typeText(text: String, submit: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null || !node.isEditable) node = findEditable(root)
        if (node == null) return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (ok && submit) {
            Thread.sleep(300)
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun pressKey(k: String): Boolean = when (k) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        else -> false
    }

    fun openApp(name: String): String {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "App not found: $name"
        val launch = pm.getLaunchIntentForPackage(m.activityInfo.packageName)
            ?: return "Cannot launch ${m.loadLabel(pm)}"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "Opened ${m.loadLabel(pm)}"
    }

    fun currentApp(): String = rootInActiveWindow?.packageName?.toString() ?: "?"

    fun blank(): Bitmap {
        val dm = resources.displayMetrics
        val b = Bitmap.createBitmap(dm.widthPixels, dm.heightPixels, Bitmap.Config.ARGB_8888)
        b.eraseColor(0xFF222222.toInt())
        return b
    }

    fun collectElements(): List<Elem> {
        val root = rootInActiveWindow ?: return emptyList()
        val dm = resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        val out = ArrayList<Elem>()
        fun walk(node: AccessibilityNodeInfo) {
            if (out.size >= 70) return
            if (node.isVisibleToUser) {
                val label = (node.text ?: node.contentDescription ?: node.hintText)
                    ?.toString()?.replace("\n", " ")?.take(50) ?: ""
                val interactive = node.isClickable || node.isEditable || node.isCheckable || node.isLongClickable
                if (label.isNotBlank() || interactive) {
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    val area = r.width().toLong() * r.height()
                    val hugeBlank = label.isBlank() && area > screenArea * 0.6
                    if (r.width() > 8 && r.height() > 8 && !hugeBlank) {
                        val kind = if (node.isEditable) "input" else if (interactive) "button" else "text"
                        out.add(Elem(out.size + 1, r, label, kind))
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i)
                if (c != null) walk(c)
            }
        }
        walk(root)
        return out
    }

    /** Real on-screen approval dialog: the app (not the model) enforces it. */
    fun confirm(question: String): Boolean {
        val latch = CountDownLatch(1)
        var answer = false
        var boxRef: View? = null
        main.post {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(48, 48, 48, 48)
            box.setBackgroundColor(Color.WHITE)
            val tv = TextView(this)
            tv.text = "⚠ Confirmare:\n\n$question"
            tv.textSize = 18f
            tv.setTextColor(Color.BLACK)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val no = Button(this)
            no.text = "NU"
            val yes = Button(this)
            yes.text = "DA, continuă"
            row.addView(no, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(yes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(tv)
            box.addView(row)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                0,
                PixelFormat.OPAQUE
            )
            lp.gravity = Gravity.CENTER
            yes.setOnClickListener {
                answer = true
                wm.removeView(box)
                latch.countDown()
            }
            no.setOnClickListener {
                wm.removeView(box)
                latch.countDown()
            }
            wm.addView(box, lp)
            boxRef = box
        }
        val got = latch.await(120, TimeUnit.SECONDS)
        if (!got) {
            main.post {
                try {
                    boxRef?.let { wm.removeView(it) }
                } catch (e: Exception) {
                }
            }
        }
        return got && answer
    }
}
