package ro.x67.agent

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {

    private val BG = 0xFF0E1116.toInt()
    private val CARD = 0xFF171B22.toInt()
    private val CARD2 = 0xFF222834.toInt()
    private val LINE = 0xFF2A303C.toInt()
    private val TEXT = 0xFFE8EAF0.toInt()
    private val MUTED = 0xFF8A93A6.toInt()
    private val ACCENT = 0xFF4C8DFF.toInt()
    private val RED = 0xFFFF5C5C.toInt()
    private val GREEN = 0xFF3DDC84.toInt()
    private val AMBER = 0xFFFFB020.toInt()

    private lateinit var p: SharedPreferences
    private lateinit var cmd: EditText
    private lateinit var keyField: EditText
    private lateinit var logView: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var chipRow: LinearLayout
    private val modelPills = ArrayList<Pair<TextView, String>>()
    private val h = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val s = AgentService.instance
            val dot = statusDot.background as GradientDrawable
            if (s == null) {
                dot.setColor(RED)
                statusText.text = "Oprit · apasă pentru activare"
            } else if (s.running) {
                dot.setColor(AMBER)
                statusText.text = "Rulează…"
            } else {
                dot.setColor(GREEN)
                statusText.text = "Activ"
            }
            val l = AgentService.log.toString().takeLast(2500)
            logView.text = if (l.isBlank()) "Nicio activitate încă." else l
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun LinearLayout.addTop(v: View, top: Int = 12) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(top)
        addView(v, lp)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun pill(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        val t = label(text, 15f, fg, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rounded(bg, 14), null)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(CARD, 20, LINE)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        return c
    }

    private fun edit(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(MUTED)
        e.setTextColor(TEXT)
        e.textSize = 16f
        e.background = rounded(CARD2, 14)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        return e
    }

    private fun loadQuick(): MutableList<String> {
        val a = JSONArray(p.getString("quick", "[]") ?: "[]")
        val l = ArrayList<String>()
        for (i in 0 until a.length()) l.add(a.getString(i))
        return l
    }

    private fun saveQuick(l: List<String>) {
        p.edit().putString("quick", JSONArray(l).toString()).apply()
    }

    private fun rebuildChips() {
        chipRow.removeAllViews()
        val add = label("＋ Salvează", 14f, ACCENT, true)
        add.setPadding(dp(14), dp(9), dp(14), dp(9))
        add.background = rounded(CARD2, 20, ACCENT)
        add.setOnClickListener {
            val t = cmd.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = loadQuick()
                if (!l.contains(t)) l.add(t)
                saveQuick(l)
                rebuildChips()
            }
        }
        chipRow.addView(add)
        for (q in loadQuick()) {
            val c = label(if (q.length > 26) q.take(26) + "…" else q, 14f, TEXT)
            c.setPadding(dp(14), dp(9), dp(14), dp(9))
            c.background = rounded(CARD2, 20)
            c.setOnClickListener {
                cmd.setText(q)
                cmd.setSelection(q.length)
            }
            c.setOnLongClickListener {
                val l = loadQuick()
                l.remove(q)
                saveQuick(l)
                rebuildChips()
                Toast.makeText(this, "Șters", Toast.LENGTH_SHORT).show()
                true
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = dp(8)
            chipRow.addView(c, lp)
        }
    }

    private fun saveKey() {
        p.edit().putString("apikey", keyField.text.toString().trim()).apply()
    }

    private fun refreshModelPills() {
        val cur = p.getString("model", "claude-sonnet-5-5")
        for ((v, id) in modelPills) {
            val sel = id == cur
            v.background = rounded(if (sel) ACCENT else CARD2, 12)
            v.setTextColor(if (sel) 0xFFFFFFFF.toInt() else MUTED)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = getSharedPreferences("cfg", 0)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(32))

        // ----- header -----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        titleBox.addView(label("Agent AI", 30f, TEXT, true))
        titleBox.addView(label("v3 · Claude controlează telefonul", 13f, MUTED))
        header.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pillBox = LinearLayout(this)
        pillBox.orientation = LinearLayout.HORIZONTAL
        pillBox.gravity = Gravity.CENTER_VERTICAL
        pillBox.background = rounded(CARD, 20, LINE)
        pillBox.setPadding(dp(12), dp(8), dp(14), dp(8))
        statusDot = View(this)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(RED)
        statusDot.background = dotBg
        pillBox.addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)))
        statusText = label("…", 13f, TEXT)
        statusText.setPadding(dp(8), 0, 0, 0)
        pillBox.addView(statusText)
        pillBox.setOnClickListener {
            if (AgentService.instance == null) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        header.addView(pillBox)
        root.addView(header)

        // ----- command card -----
        val cc = card()
        cc.addView(label("Ce să fac pe telefon?", 14f, MUTED, true))
        cmd = edit("ex: deschide Superbet și fă un bilet cu cota 5")
        cmd.background = null
        cmd.setPadding(0, dp(8), 0, dp(8))
        cmd.minLines = 3
        cmd.gravity = Gravity.TOP
        cmd.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        cc.addView(cmd)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val mic = pill("🎤", CARD2, TEXT) {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ro-RO")
            try {
                startActivityForResult(i, 1)
            } catch (e: Exception) {
                Toast.makeText(this, "Recunoașterea vocală nu e disponibilă", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(mic, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val run = pill("▶  Rulează", ACCENT, 0xFFFFFFFF.toInt()) {
            saveKey()
            val s = AgentService.instance
            val t = cmd.text.toString().trim()
            if (s == null) {
                Toast.makeText(this, "Activează întâi serviciul de accesibilitate", Toast.LENGTH_LONG).show()
            } else if (t.isEmpty()) {
                Toast.makeText(this, "Scrie o comandă", Toast.LENGTH_SHORT).show()
            } else {
                s.startTask(t)
                moveTaskToBack(true)
            }
        }
        val rlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        rlp.leftMargin = dp(8)
        rlp.rightMargin = dp(8)
        row.addView(run, rlp)
        val stop = pill("■", 0xFF3A1D1F.toInt(), RED) { AgentService.instance?.stopRequested = true }
        row.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cc.addTop(row, 8)
        root.addTop(cc, 20)

        // ----- quick commands -----
        val qc = card()
        qc.addView(label("Comenzi rapide", 14f, MUTED, true))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(chipRow)
        qc.addTop(hs, 10)
        qc.addTop(label("Ține apăsat pe o comandă ca s-o ștergi.", 12f, MUTED), 8)
        root.addTop(qc, 12)

        // ----- activity log -----
        val lc = card()
        val lh = LinearLayout(this)
        lh.orientation = LinearLayout.HORIZONTAL
        lh.addView(label("Activitate", 14f, MUTED, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clear = label("Șterge", 13f, ACCENT, true)
        clear.setOnClickListener { AgentService.log.setLength(0) }
        lh.addView(clear)
        lc.addView(lh)
        logView = label("", 12f, 0xFFB7BFD0.toInt())
        logView.typeface = Typeface.MONOSPACE
        lc.addTop(logView, 10)
        root.addTop(lc, 12)

        // ----- settings (collapsible) -----
        val sc = card()
        val sh = label("⚙  Setări  ▾", 15f, TEXT, true)
        sc.addView(sh)
        val sb = LinearLayout(this)
        sb.orientation = LinearLayout.VERTICAL
        sb.visibility = if ((p.getString("apikey", "") ?: "").isBlank()) View.VISIBLE else View.GONE
        sh.setOnClickListener { sb.visibility = if (sb.visibility == View.VISIBLE) View.GONE else View.VISIBLE }

        sb.addTop(label("Cheie API Anthropic", 13f, MUTED, true), 14)
        keyField = edit("sk-ant-...")
        keyField.setText(p.getString("apikey", ""))
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyField.setSingleLine()
        sb.addTop(keyField, 6)

        sb.addTop(label("Model", 13f, MUTED, true), 14)
        val mrow = LinearLayout(this)
        mrow.orientation = LinearLayout.HORIZONTAL
        val models = listOf("⚡ Rapid" to "claude-haiku-5-5", "⚖ Echilibrat" to "claude-sonnet-5-5", "🧠 Maxim" to "claude-opus-5-5")
        for ((name, id) in models) {
            val t = label(name, 13f, MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(12), dp(8), dp(12))
            t.setOnClickListener {
                p.edit().putString("model", id).apply()
                refreshModelPills()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.rightMargin = dp(6)
            mrow.addView(t, lp)
            modelPills.add(t to id)
        }
        sb.addTop(mrow, 6)
        refreshModelPills()

        val sw = Switch(this)
        sw.text = "Cere confirmare înainte de plăți/pariuri"
        sw.setTextColor(TEXT)
        sw.isChecked = p.getBoolean("confirm", false)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean("confirm", c).apply() }
        sb.addTop(sw, 16)

        sb.addTop(pill("Salvează cheia", ACCENT, 0xFFFFFFFF.toInt()) {
            saveKey()
            Toast.makeText(this, "Salvat", Toast.LENGTH_SHORT).show()
        }, 16)
        sb.addTop(pill("1 · Permite setări restricționate", CARD2, TEXT) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, 10)
        sb.addTop(pill("2 · Activează accesibilitatea", CARD2, TEXT) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, 8)
        sc.addTop(sb, 0)
        root.addTop(sc, 12)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.addView(root)
        setContentView(scroll)
        rebuildChips()
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        saveKey()
        h.removeCallbacks(tick)
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (r != null) cmd.setText(r)
        }
    }
}
