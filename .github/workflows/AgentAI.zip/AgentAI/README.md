# Agent AI Telefon
1. Urcă conținutul în GitHub, workflow-ul din .github/workflows/build.yml compilează APK-ul (Actions -> Artifacts -> agent-ai-apk).
2. Instalează APK-ul, deschide aplicația, pune cheia API, apoi Pasul 1 + Pasul 2 (accesibilitate).
